package tinnova.avaliacao.alexgaudencio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlexgaudencioApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlexgaudencioApplication.class, args);
	}

}
